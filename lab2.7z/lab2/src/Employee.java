public class Employee {
    public String name;
    public String departmentname;
    public double salary;
    public int id;
    public int managerId;

    public Employee(String name,String departmentname,double salary,int id,int managerId){
        this.name = name;
        this.salary = salary;
        this.id = id;
        this.managerId = managerId;
        this.departmentname = departmentname;
    }

    public double getSalary() {
        return salary;
    }

    public int getId() {
        return id;
    }

    public int getManagerId() {
        return managerId;
    }

    public String getDepartmentname() {
        return departmentname;
    }

    public String getName() {
        return name;
    }
}
