import java.util.ArrayList;

public class Packing {
    Burger burgir;
    ColdDrink drink;

    public void setter(Burger meal,ColdDrink to_drink){
        burgir = meal;
        drink = to_drink;
    }
}
