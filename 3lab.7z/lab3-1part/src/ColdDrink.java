public class ColdDrink {
    float price;
    String name;
}
