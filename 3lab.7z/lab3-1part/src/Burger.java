public class Burger  {
    float price;
    String name;
}
