public class ChickenBurger extends Burger {
    void setter(float number,String text){
        price = number;
        name = text;
    }
}
