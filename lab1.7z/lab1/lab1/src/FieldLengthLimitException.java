public class FieldLengthLimitException extends Exception
{
    public FieldLengthLimitException()
    {
        super();
    }
    public FieldLengthLimitException(String msg)
    {
        super("too many characters: " + msg);
    }
}