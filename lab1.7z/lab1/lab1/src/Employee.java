public class Employee {

    private int id;
    private String name;
    private String surname;
    private double salary;

    public void setSalary(double salary) throws NegativeValueException {
        if (salary < 0) {
            throw new NegativeValueException(salary);
        } else
            this.salary = salary;
    }

    public void setName(String name) throws FieldLengthLimitException {
        if (name.length() > 4) {
            throw new FieldLengthLimitException(name);
        } else
            this.name = name;
    }
}

