public class Coke extends ColdDrink{
    void setter(float number,String text){
        price = number;
        name = text;
    }
}
