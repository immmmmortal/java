public class RedCircle implements Shape {

    @Override
    public void draw() {
        System.out.println("RedCircle::draw()");
    }
}