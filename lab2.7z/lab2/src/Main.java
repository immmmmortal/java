public class Main {
    public static void main(String[] args) throws EmployeeInRegistryException {
        Employee e1 = new Employee("john","yeet",200,1,1);
        Employee e2 = new Employee("johny","salary",150,1,1);
        Employee e3 = new Employee("weak","management",185,1,1);
        Employee e4 = new Employee("will","clerks",190,1,1);
        Manager m1 = new Manager();
        Registry r = new Registry();
        r.getRegistry(e1);
        r.getRegistry(e1);
        r.getRegistry(e2);
        r.printList();
    }
}