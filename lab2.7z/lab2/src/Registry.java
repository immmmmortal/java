import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Registry {
    public List<Employee> workers = new ArrayList<>() {
    };

    public void getRegistry(Employee worker) throws EmployeeInRegistryException { // adds worker to ArrayList
        if (workers.contains(worker)) {
            throw new EmployeeInRegistryException("Worker with that id exists" + worker.id);
        }
        else workers.add(worker);
    }

     public void printList() {
        System.out.println(Arrays.toString(workers.toArray()));
    }
}
