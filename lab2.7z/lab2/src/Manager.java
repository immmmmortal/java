public class Manager {
    public double bonus;

    public double getBonus() {
        return bonus;
    }
}
