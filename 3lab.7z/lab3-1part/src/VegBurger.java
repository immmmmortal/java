public class VegBurger extends Burger{
    void setter(float number,String text){
        price = number;
        name = text;
    }
}
