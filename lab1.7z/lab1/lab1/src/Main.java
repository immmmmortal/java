public class Main {
    public static void main(String[] args) throws NegativeValueException, FieldLengthLimitException {
    Employee employee1 = new Employee();
    employee1.setSalary(1);
    employee1.setName("sofll");
    }
}

