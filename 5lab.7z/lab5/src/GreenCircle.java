public class GreenCircle implements Shape {

    @Override
    public void draw() {
        System.out.println("GreenCircle::draw()");
    }
}